/**
 * Created by 或彼此 on 2017/6/29.
 */
window.onload=function () {
    alert("这是js内容")
};